package service;

public class ProfissionalService {
}
