package DATABASE;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class db {
    private static final String URL = "jdbc:h2:~/test"; // Caminho do banco de dados
    private static final String USER = "sa"; // Usuário padrão do H2
    private static final String PASSWORD = ""; // Senha padrão do H2 (pode ser vazia)

    private Connection connection;

    // Método para abrir a conexão
    public void openConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexão com o banco de dados H2 estabelecida com sucesso.");
        }
    }

    // Método para fechar a conexão
    public void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Conexão com o banco de dados H2 fechada.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // Método para obter a conexão
    public Connection getConnection() {
        return connection;
    }
}
