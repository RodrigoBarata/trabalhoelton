package DATABASE;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseInitializer {
    private db dbConnection;

    public DatabaseInitializer() {
        this.dbConnection = new db();
    }

    public void criarTabelaProfissional() {
        String sql = "CREATE TABLE IF NOT EXISTS Profissional (" +
                "id INT AUTO_INCREMENT PRIMARY KEY, " +
                "nome VARCHAR(255) NOT NULL, " +
                "email VARCHAR(255) NOT NULL," +
                " CPF VARCHAR(255) NOT NULL," +
                " licenca VARCHAR(255) NOT NULL," +
                " certificado VARCHAR(255) NOT NULL" +
                ");";

        try {
            dbConnection.openConnection();
            Connection connection = dbConnection.getConnection();
            Statement statement = connection.createStatement();
            statement.executeUpdate(sql);
            System.out.println("Tabela 'entity.Profissional' criada com sucesso!");

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            dbConnection.closeConnection();
        }
    }
}
