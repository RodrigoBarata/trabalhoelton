import DATABASE.DatabaseInitializer;
import dao.ProfissionalDAO;
import entity.Profissional;

import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        try {
            // Inicializar o banco de dados e criar a tabela
            DatabaseInitializer dbInitializer = new DatabaseInitializer();
            dbInitializer.criarTabelaProfissional();

            // Iniciar o servidor HTTP
            SimpleHttpServer httpServer = new SimpleHttpServer( 8090);
            httpServer.start();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
