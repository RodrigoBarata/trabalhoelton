import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import dao.ProfissionalDAO;
import entity.Profissional;

import java.io.*;
import java.net.InetSocketAddress;

public class SimpleHttpServer {
    private HttpServer server;

    public SimpleHttpServer(int port) throws IOException {
        // Criar o servidor na porta especificada
        server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/salvarProfissional", new SalvarProfissionalHandler());
        server.setExecutor(null); // Cria um executor padrão
    }

    public void start() {
        server.start(); // Inicia o servidor
        System.out.println("Servidor iniciado na porta " + server.getAddress().getPort() + "...");
    }

    private static class SalvarProfissionalHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            // Adiciona os cabeçalhos CORS
            exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
            exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "POST, OPTIONS");
            exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");

            // Verifica se é uma requisição OPTIONS
            if ("OPTIONS".equals(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(204, -1); // No Content
                return;
            }

            if ("POST".equals(exchange.getRequestMethod())) {
                InputStream inputStream = exchange.getRequestBody();
                String json = new BufferedReader(new InputStreamReader(inputStream))
                        .lines()
                        .collect(java.util.stream.Collectors.joining("\n"));

                // Suponha que o JSON esteja no formato {"nome": "valor", "email": "valor"}
                String nome = json.split("\"")[3];  // Ajuste conforme necessário
                String email = json.split("\"")[7]; // Ajuste conforme necessário
                String CPF = json.split("\"")[11]; // Ajuste conforme necessário
                String licenca = json.split("\"")[15]; // Ajuste conforme necessário
                String certificado = json.split("\"")[19]; // Ajuste conforme necessário

                // Salva o profissional no banco de dados
                ProfissionalDAO profissionalDAO = new ProfissionalDAO();
                profissionalDAO.salvar(new Profissional(nome, email, CPF, licenca, certificado));

                String response = "Profissional salvo com sucesso!";
                exchange.sendResponseHeaders(200, response.length());
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(response.getBytes());
                }
            } else {
                String response = "Método não permitido";
                exchange.sendResponseHeaders(405, response.length());
                try (OutputStream os = exchange.getResponseBody()) {
                    os.write(response.getBytes());
                }
            }
        }
    }

    public static void main(String[] args) {
        try {
            SimpleHttpServer httpServer = new SimpleHttpServer(8090); // Cria o servidor na porta 8090
            httpServer.start(); // Chama o método start para iniciar o servidor
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
