package dao;

import entity.Profissional;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import DATABASE.db;

public class ProfissionalDAO {
    private db dbConnection;

    public ProfissionalDAO() {
        this.dbConnection = new db();
    }

    public void salvar(Profissional Profissional) {
        String sql = "INSERT INTO Profissional (nome, email,CPF,licenca,certificado) VALUES (?, ?,?,?,?,?)";

        try {
            dbConnection.openConnection();
            Connection connection = dbConnection.getConnection();
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, Profissional.getNome());
            statement.setString(2, Profissional.getEmail());
            statement.setString(3, Profissional.getCPF());
            statement.setString(4, Profissional.getLicenca());
            statement.setString(5, Profissional.getCertificado());
            statement.executeUpdate();
            System.out.println("Usuário salvo com sucesso!");

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            dbConnection.closeConnection();
        }
    }
}
